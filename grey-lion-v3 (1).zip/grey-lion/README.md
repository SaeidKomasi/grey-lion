# Grey Lion

Simple Next.js landing page V3.
